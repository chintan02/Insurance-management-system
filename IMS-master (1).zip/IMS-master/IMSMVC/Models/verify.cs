﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMSMVC.Models
{
    public class verify
    {
        public int otp { get; set; }
    }
}